# Fire Thermal Analysis Method: Zone Models of Standard Burner Flames

| | |
| --- | --- |
| Document type | Method document (reference for fire thermal analysis) |
| Issue / date | Draft E, 2026-11-23 |
| Classification | Airbus Amber (derived from source material of that classification) |
| Author | — |
| Checked | — |
| Approved | — |

## 1. Context and certification basis

### 1.1 Purpose and scope

#### 1.1.1 Purpose

This document defines the method for thermal simulation of aircraft structure, components and materials exposed to the standard burner flames used in CS-25 fire certification. It applies to all fire thermal models using these flames. It gives:

- the certification basis that the simulation supports;
- the convecto-radiative zone model common to all burners, and the burner data (zone geometry, number of zones, parameters);
- the toolset and the process, from fire scenario to results delivered to stress or to the compliance demonstration;
- the extension of the zone models to non-flat impinged geometry;
- the fire-specific points of attention;
- the range of validity, the data sources in case of doubt, the treatment of cases outside the range (uncertainty quantification and margins) and the limitations.

#### 1.1.2 Burners covered

| Burner (standard) | Flame type | Section |
| --- | --- | --- |
| ISO 2685 / FAA AC 20-135 | Powerplant fire (designated fire zones) | 1.5.1, 2.3.1 |
| CS-25 Appendix F Part VII | Fuselage burn-through (post-crash fire, thermal/acoustic insulation) | 1.5.2, 2.3.2 |
| CS-25 Appendix F Part III | Cargo compartment fire (liner flame penetration) | 1.5.3, 2.3.3 |

All three burners use the same model form (section 2.2). They differ only in zone geometry, number of zones, zone dimensions and parameter values (VF_i, HTC_i, T_ref). All other sections apply to all burners unless a burner section states otherwise.

Status: the Part VII and Part III zone maps and parameters are not given in this issue. Sections 2.3.2 and 2.3.3 are usable only once the identification reports [22] and [23] are issued and their data entered.

#### 1.1.3 Applications

| Application | Status |
| --- | --- |
| De-risking of a certification fire test | Covered |
| Numerical reproduction of a fire test | Covered |
| Fire impact on a part as installed on the aircraft | Covered |
| Adjacent zone impact assessment | Covered |
| Substitution of a certification fire test | Only where accepted by the authority for the programme (section 1.4.4) |

#### 1.1.4 Exclusions

| Case | Reason |
| --- | --- |
| Torching flame (CS 25.903(d)(1); AMC 25.903(d)(1): combustion chamber burnthrough) | Flame temperature, pressure and footprint outside all identified models (section 1.4.3.4) |
| Materials that decompose, outgas or burn at the impinged face (composites, liner and blanket materials) | Heat release and gas transport not represented. The zone model gives the incident boundary condition only (section 2.7.6) |
| Burn-through of the specimen (Part III and Part VII pass/fail by flame penetration) | Material degradation not represented. The model supports the thermal part of the assessment only |
| Other fire tests of CS-25 Appendix F (Parts I, II, IV, V, VI) | Different test methods; no zone model |

#### 1.1.5 Conventions

- "Shall": mandatory for analyses claiming compliance with this method. A departure requires a documented justification accepted by the thermal specialist in charge and recorded in the analysis report.
- "Should": recommended practice. A departure is recorded in the analysis report with its justification.
- Chapter 1, tables of data, statements of physical description, rationale, history or status, and Appendices A to D are informative.
- In sections 2.1 to 2.3 and 2.5 to 2.10, statements that prescribe an action, a value, or a content of the analysis or of the report, without "should" or "may", are requirements.
- Section 2.4: the assignment rules of 2.4.3 steps 1 to 10 are recommended defaults; a departure is recorded in the analysis report with its justification. The following are requirements: confirmation of the zone map in the alignment meeting (2.4.1, 2.1.3); the hottest-zone area check (2.4.3 step 11); the documentation of 2.4.3 step 12; the evaluation of every trigger of 2.4.4; the escalation route of 2.4.5 once a trigger applies (2.8.6).
- Temperatures in °C unless stated in K; T[K] = T[°C] + 273. Heat flux density in W/m², kW/m² or W/cm².
- Zone numbering: Z1 is the zone of highest flux, ZN the outermost heated zone. "Hottest zone" means Z1; "outermost contour" is the outer line of ZN.

### 1.2 References

#### 1.2.1 Regulatory and standards

| Ref. | Document |
| --- | --- |
| [1] | EASA CS-25, Amendment 27, and AMC: CS 25.855, 25.856, 25.857, 25.859, 25.863, 25.865, 25.867, 25.869, 25.903(d)(1), 25.1181, 25.1182, 25.1183, 25.1185 to 25.1203, 25.1309; CS 25J paragraphs for APU installations (CS 25J1181 to 25J1203); AMC 25.856(b), AMC 25.903(d)(1), AMC 25.1181, AMC 25.1193(e); Appendix F Parts III and VII |
| [2] | ISO 2685, Aircraft — Environmental conditions and test procedures for airborne equipment — Resistance to fire in designated fire zones. AMC 25.1181 cites the edition of 15 July 1992; the 1998 edition is current. Edition to be stated per programme |
| [3] | 14 CFR Part 25 (largely the same paragraph numbers as CS-25) and 14 CFR 1.1 (definitions of fireproof and fire resistant) |
| [4] | FAA AC 20-135, Powerplant Installation and Propulsion System Component Fire Protection Test Methods, Standards and Criteria; AC 20-135A with SAE AS6826 (issue status of AC 20-135A to be confirmed) |
| [5] | FAA AC 25.856-2A, Installation of Thermal/Acoustic Insulation for Burnthrough Protection (29/07/2008), accepted by AMC 25.856(b) |
| [6] | EASA CS-Definitions (fireproof, fire resistant) |
| [7] | BSI 3G100 Part 2 Section 3 Sub-section 3.13 (December 1973), cited by AMC 25.903(d)(1) |

#### 1.2.2 Internal references

Document numbers to be completed.

| Ref. | Subject |
| --- | --- |
| [8] | ISO 2685 standard flame thermal model presentation (cited as "source presentation") |
| [9] | Zone projection procedure (zone_projection_procedure.md, 2026-10-31), superseded by this document |
| [10] | Standard flame thermal model (ISO 2685): zone definition and parameters |
| [11] | R&T project ACTIFF (2004): identification of the ISO 2685 model (two zones) |
| [12] | R&T project COMPUP (2014): A350-1000 pylon composite upper spar; third zone of the ISO 2685 model |
| [13] | A350 XWB rear engine mounts MOD: hybrid Inconel/titanium to full titanium (simplified calibration test) |
| [14] | A350 XWB Section 19.1 composite firewall removal |
| [15] | A321XLR composite fire analysis |
| [16] | A380 Trent 900 pylon torch flame analysis; A380 EA/RR forward engine mount shackles |
| [17] | Stress process for residual strength in a fire scenario |
| [18] | Allowable Maximum Hot Day (AMHD) thermal mission |
| [19] | Thermal Analysis Report Template (NOC model validation, mapping process, visual identity) |
| [20] | NOC thermal modelling guidelines |
| [21] | STT008 (local model boundary conditioning from global model results) |
| [22] | Appendix F Part VII zone model: identification report |
| [23] | Appendix F Part III zone model: identification report |

### 1.3 Abbreviations and terms

#### 1.3.1 Abbreviations

| Abbreviation | Meaning |
| --- | --- |
| 1ACST | Department to contact for composite fire analysis and for zone model calibration decisions |
| AC | FAA Advisory Circular |
| AMC | Acceptable Means of Compliance |
| AMHD | Allowable Maximum Hot Day (mission) |
| APU | Auxiliary power unit |
| BC | Boundary condition (Figure 7) |
| CFD | Computational fluid dynamics |
| CS | Certification Specification |
| EASA | European Union Aviation Safety Agency |
| FAA | Federal Aviation Administration |
| Fire DCS | Fire certification specialist (role name in the PRA process; expansion to be completed) |
| FESRA | Fire risk analysis within the PRA process (expansion to be completed) |
| HTC | Heat transfer coefficient |
| MOD | Modification |
| NOC | Normal Operating Conditions |
| PRA | Particular Risk Analysis |
| R&T | Research and technology |
| RF | Reserve factor |
| RH | Relative humidity |
| ToO | Time of occurrence (of the fire) |
| VF | Equivalent grey-body view factor |

#### 1.3.2 Terms

| Term | Definition in this document |
| --- | --- |
| Designated fire zone | Region listed in CS 25.1181(a): engine power and accessory sections, complete powerplant compartments without isolation, fuel-burning heater and other combustion equipment installations (CS 25.859), compressor and accessory sections of turbine engines, combustor/turbine/tailpipe sections containing lines or components carrying flammable fluids or gases |
| Firewall | Fireproof wall or shroud isolating each engine, fuel-burning heater, other combustion equipment intended for operation in flight, and the combustion, turbine and tailpipe sections of turbine engines from the rest of the aircraft (CS 25.1191) |
| Fireproof | CS-Definitions [6] (wording to be confirmed against [6]; not contained in the CS-25 document): capability to withstand the application of heat by a flame for 15 min without failure creating a hazard; for materials, at least as well as steel or titanium in dimensions appropriate for the purpose. 14 CFR 1.1 [3]: at least as well as steel. Statement of the flame (1100 °C ± 80 °C, 116 kW/m² ± 10 kW/m²) in [6]: to be confirmed |
| Fire resistant | CS-Definitions [6] (wording to be confirmed against [6]): same for 5 min; for materials, at least as well as aluminium alloy in dimensions appropriate for the purpose. 14 CFR 1.1 [3]: at least as well as aluminium alloy |
| Standard flame | Flame of the ISO 2685 / AC 20-135 burner, calibrated in temperature and heat flux (section 1.5.1.1) |
| Burn-through | Penetration of an external post-crash fuel fire into the fuselage; for Part VII, time for the flame to penetrate the specimen or for the cold-side heat flux to reach 2.27 W/cm² at 30.5 cm from the frame face, whichever is sooner |
| Flame penetration | Passage of flame through a liner specimen (Part III) |
| Cargo compartment classes | CS 25.857 classes A, B, C, E, F, defined by accessibility, detection and suppression. Liners separate from, but possibly attached to, the aeroplane structure are required for classes B to E, and for F unless other means of containing the fire and protecting critical systems and structure are provided (CS 25.855(b)) |
| Calibration plane | Plane of the identification plate, in which the zones of a map are defined. It is the burner calibration position, except for the Part III sidewall map |
| Burner attitude | Direction of the burner axis relative to gravity |
| Burner section | Burner data in section 1.5 (tests: burner summary table and section 1.5.1, 1.5.2 or 1.5.3) and section 2.3 (zone models: section 2.3.1, 2.3.2 or 2.3.3) |
| Zone map | The set of N zone contours of a burner model in its calibration plane, with the burner axis trace and the gravity direction |
| Impinged (wetted) face | Face of category K1 to K4 (2.4.3 step 5), carrying the zone flux. "Wetted" is not used elsewhere. "Exposed" is used only for structure uncovered after loss of a part (2.7.8) |
| Face category | K0 (not impinged), K1 (visible), K2 (wrapped), K3 (sheltered) or K4 (behind a wall), assigned by 2.4.3 step 5 |
| θ | Angle between the outward normal of a face and the projection direction pointing toward the cone exit plane (2.4.3 step 5) |
| Visible face | Face with θ ≤ 100° from which the line along the projection direction toward the cone exit plane meets no part (2.4.3 step 5(c)) |
| Hidden face | Face inside the outermost contour, not visible and not of category K0 or K4 (2.4.3 step 6) |
| Shadowing part | Part met first by the line from a hidden face along the projection direction toward the cone exit plane; for a face with θ > 100°, the part carrying the face. Parts joined without opening count as one part (2.4.3 step 6) |
| b | Smallest dimension of the outline of the shadowing part projected on the calibration plane, at the section containing the face (2.4.3 step 6) |
| Stand-off s | Distance from the cone exit plane to the calibration plane of the map, along the projection direction (burner section) |
| Reference surface | Physical surface of the specimen to which the scenario stand-off is measured (2.4.3 step 3) |
| Reference plane | Plane parallel to the calibration plane through the point where the burner axis meets the reference surface; where the axis does not meet it, through the point of the reference surface nearest to the cone exit plane |
| x | Distance of a face from the cone exit plane along the projection direction |
| D1 | Smallest in-plane dimension of the hottest-zone contour (ISO 2685: 200 mm; 0.25 D1 = 50 mm) |
| w, d | Smallest dimension of a cavity opening; depth of the cavity (2.4.3 step 8) |
| Narrow part | Part, or portion of a part, whose outline projected on the calibration plane along the projection direction has a smallest dimension below D1 (bracket, clip, tube, flange, stiffener, fitting, web parallel to the projection direction) |
| Wall | Part, or assembly of parts joined without opening, whose outline projected on the calibration plane along the projection direction has a smallest dimension of D1 or more (not a narrow part) |
| Opening | Hole, slot, gap or unsealed joint through a wall, of free area above 1 % of the area enclosed by the hottest-zone contour (ISO 2685: 314 mm²). Smaller openings are disregarded in 2.4.3 step 5 and recorded |
| Free edge | Edge of a wall not joined or sealed to adjacent structure or fixture |
| Behind a wall | Inside the outline of the wall extruded along the projection direction, on the side away from the burner, up to the next wall |
| Test calibration | Recalibration of VF_i and HTC_i on a test representative of the configuration (2.4.5 level 4). Distinct from the burner calibration (section 1.5) and the calibration check (2.2.5) |
| Fire risk lead | Lead of the fire scenario definition and of the design justification; for powerplant, the FESRA PRA task leader. Whether the Fire DCS holds the same role: to be confirmed |

### 1.4 Certification basis

#### 1.4.1 Regulatory framework

- CS-25 (EASA) and 14 CFR Part 25 [3] (FAA) give the airworthiness requirements for large aeroplanes, with largely the same paragraph numbering; content differs in places (example: CS 25.1193(e); CS-25 Subpart J for APU). A CS paragraph states the requirement; an AMC gives one acceptable means of compliance; FAA Advisory Circulars are the FAA equivalent, and some are accepted by EASA through an AMC (example: AMC 25.856(b) accepts AC 25.856-2A).
- CS-25 Appendix F defines the flammability and fire test methods called by the requirements.
- The certification basis of a programme fixes the applicable amendment and any special conditions (example: post-crash fire survivability of composite fuselages). The thermal analysis uses the requirement text of that certification basis.
- Compliance is shown by test, analysis, similarity or a combination, as agreed with the authority. The use of a thermal analysis in lieu of a test is agreed per programme.

#### 1.4.2 Fire threats and requirements

| Fire threat | Requirement | Test | Burner section |
| --- | --- | --- | --- |
| Fire in a designated fire zone (engine, APU, combustion heater) | CS 25.865, 25.867, 25.869(a)(2), 25.1182, 25.1183, 25.1191, 25.1193, and the corresponding CS 25J paragraphs for APU; AMC 25.1181, AMC 25.1193(e) | ISO 2685 / AC 20-135, 5 min (fire resistant) or 15 min (fireproof) | 1.5.1, 2.3.1 |
| External post-crash fuel fire penetrating the fuselage | CS 25.856(b), AMC 25.856(b); special conditions for composite fuselages | Appendix F Part VII, 4 min | 1.5.2, 2.3.2 |
| Fire inside a cargo compartment | CS 25.855(b), (c); CS 25.857 | Appendix F Part III, 5 min | 1.5.3, 2.3.3 |
| Combustion chamber burn-through (torching flame) | CS 25.903(d)(1), AMC 25.903(d)(1) | BSI 3G100 Part 2 Section 3 Sub-section 3.13 | Not covered |

#### 1.4.3 Requirement text

##### 1.4.3.1 Powerplant fire

| Paragraph | Requirement (CS-25 Amdt 27; quotations are verbatim) |
| --- | --- |
| CS 25.865 | "Essential flight controls, engine mounts, and other flight structures located in designated fire zones or in adjacent areas which would be subjected to the effects of fire in the fire zone must be constructed of fireproof material or shielded so that they are capable of withstanding the effects of fire." |
| CS 25.867 | (a): surfaces to the rear of the nacelles, within one nacelle diameter of the nacelle centreline: at least equivalent in resistance to fire to aluminium alloy in appropriate dimensions. (b): not applicable to tail surfaces not readily affected by heat, flames or sparks from a designated fire zone or engine compartment |
| CS 25.869(a)(2) | Equipment in designated fire zones used during emergency procedures: at least fire resistant |
| CS 25.1181 | Lists the designated fire zones; each zone meets CS 25.863, 25.867, 25.869 and 25.1185 to 25.1203 |
| AMC 25.1181 | ISO 2685 (15 July 1992) "gives test conditions and methods of demonstrating compliance with the ‘Fire-resistant’ and ‘Fireproof’ requirements". Tests may not be necessary if similarity is shown with other components tested to this standard. Examples of materials considered satisfactory for firewalls without fire test: stainless steel sheet 0.4 mm (0.016 in); mild steel sheet protected against corrosion 0.45 mm (0.018 in); titanium sheet 0.45 mm (0.018 in) |
| CS 25.1182 | Nacelle areas behind firewalls and engine pod attaching structures containing flammable fluid lines meet the designated fire zone requirements listed in the paragraph |
| CS 25.1183 | (a): flammable fluid lines, fittings and components in areas subject to engine fire: fire resistant; flammable fluid tanks and supports in a fire zone fireproof or enclosed by a fireproof shield, unless damage by fire to any non-fireproof part will not cause leakage or spillage; components within a fire zone whose fire damage could spread fire or cause unintentional operation of, or inability to operate, essential services or equipment: fireproof. (b): not applicable to lines approved as part of a type-certificated engine, nor to vent and drain lines whose failure adds no fire hazard |
| CS 25.1191 | Firewalls and shrouds: fireproof; no hazardous quantity of air, fluid or flame passes; openings sealed with fireproof grommets, bushings or fittings; protected against corrosion |
| CS 25.1193(c), (d) | On aeroplanes with a diaphragm isolating the engine power section from the accessory section: accessory-section cowling subject to flame fireproof and meeting CS 25.1191. Cowling parts subject to high temperatures due to nearness to exhaust system parts or exhaust gas impingement: fireproof |
| CS 25.1193(e) | No fire originating in a fire zone enters, through openings or by burning through external skin, any other zone or region where it would create additional hazards. Cowlings and nacelle skins in areas subject to flame: fireproof in flight; on ground, fireproof where burn-through would affect critical areas, fire-resistant or compliant with (e)(1) in the remaining portions |
| AMC 25.1193(e) | Flight: credit for external airflow may be taken; engine/APU operative for the first 5 min, then 10 min windmilling (engine) or stopped (APU). Ground: no airflow credit (aircraft may be static); engine/APU operative 5 min then stopped 10 min; requirement applied with the engine operating or not operating, whichever is more critical; operating conditions justified by the applicant ((e)(3)(i)(C)). Fire testing according to ISO 2685 with representative airflow, loads and vibration; pass/fail criteria covering burn-through, elongation, dislocation. Airflow substantiation may use CFD |

Materials treated as fireproof without test, internal practice (source presentation [8], S5); AMC 25.1181 item 3 covers firewall sheet only:

- Stainless steel and Inconel (treated as stainless steel): loaded structure, thickness appropriate to the purpose, minimum 0.4 mm.
- Titanium, minimum 0.45 mm: fireproof by definition for EASA. The FAA does not consider titanium fireproof by definition for structure; fireproofness of titanium structure is to be demonstrated by test or by equivalent fire thermal analysis for FAA-validated products.
- The minimum thicknesses relate to fire containment (firewall sheet). Load-carrying capability under fire is demonstrated separately.

##### 1.4.3.2 Fuselage burn-through

| Paragraph | Requirement |
| --- | --- |
| CS 25.856(b) | Aeroplanes with a passenger capacity of 20 or more: "thermal/acoustic insulation materials (including the means of fastening the materials to the fuselage) installed in the lower half of the aeroplane fuselage must meet the flame penetration resistance test requirements of Part VII of Appendix F to CS-25, or other approved equivalent test requirements". Not applicable to installations the Agency finds would not contribute to fire penetration resistance |
| AMC 25.856(b) | FAA AC 25.856-2A [5] accepted as means of compliance |
| Appendix F Part VII (h) | Each of the two specimens: no fire or flame penetration in less than 4 min; no more than 2.27 W/cm² (2.0 Btu/ft²·s) on the cold side at 30.5 cm (12 in) from the face of the test rig |
| Special conditions | For composite fuselages, programme special conditions on post-crash fire survivability. Requirement taken from the programme certification basis |

##### 1.4.3.3 Cargo compartment fire

| Paragraph | Requirement |
| --- | --- |
| CS 25.855(b) | Class B to E compartments, and class F unless other means of containing the fire and protecting critical systems and structure are provided: liner separate from, but possibly attached to, the aeroplane structure |
| CS 25.855(c)(1) | Ceiling and sidewall liner panels of class C compartments (and class F where installed per (b)(2)): Appendix F Part III or approved equivalent |
| CS 25.855(c)(2) | Class E: recorders, windows, and systems or equipment in or near the compartment essential for continued safe flight and landing (CS 25.1309) adequately protected; protective covers meet Appendix F Part III |
| Appendix F Part III (a) | At least three specimens; each specimen includes the design features (joints, lamp assemblies, etc.) whose failure would affect the capability of the liner to contain a fire; no flame penetration within 5 min; peak temperature at 10 cm (4 in) above the upper surface of the horizontal specimen ≤ 204 °C (400 °F) |

##### 1.4.3.4 Torching flame

CS 25.903(d)(1) (turbine engine installations) requires design precautions to minimise the hazards to the aeroplane in the event of a fire originating within the engine which burns through the engine case. AMC 25.903(d)(1) accepts BSI 3G100 Part 2 Section 3 Sub-section 3.13 for torching-flame-resistant components and materials. Values given in the source presentation [8] from 3G100 and AC 20-135: minimum flame temperature 1745 °C (3172 °F); pressure equal to the maximum burner pressure of the installed engine, 24 bar to 38 bar; nozzle diameter 25.4 mm; barrier integrity for at least 3 min at a minimum flame temperature of 3000 °F. The two temperatures are quoted from different paragraphs; confirm against [4] and [7]. The zone models of this document shall not be used for the torching flame.

#### 1.4.4 Means of compliance and role of the thermal simulation

- Uses of the thermal simulation:
  - select the critical configuration and impingement location before a test;
  - size the design and the test specimen;
  - reproduce a test numerically and extend its results to configurations not tested (similarity; AMC 25.1181 item 2 by analogy, subject to authority agreement);
  - assess the fire impact on the part as installed (mission, initial temperature, adjacent structure) and feed the residual strength justification (section 2.1.4).
- For the ISO 2685 model, the two-zone version has been presented to the authorities and accepted as a fire test substitute (source presentation [8]). The acceptance status of the three-zone version and of the Part VII and Part III models is stated per programme.
- Where the simulation is used in lieu of a test, the analysis report states the agreement with the authority and its reference.

### 1.5 Standard burner tests

Each burner section gives only what differs between burners: test, calibration, zone map and parameters, burner-specific validity and points of attention. "Burner section" (1.3.2) means the burner summary below and section 1.5.1, 1.5.2 or 1.5.3, together with section 2.3.1, 2.3.2 or 2.3.3. Zone maps, parameters and burner-specific points: section 2.3.

Burner summary:

| Item | ISO 2685 / AC 20-135 | Appendix F Part VII | Appendix F Part III |
| --- | --- | --- | --- |
| Requirement | Section 1.4.3.1 | Section 1.4.3.2 | Section 1.4.3.3 |
| Exposure | 5 min (fire resistant), 15 min (fireproof) | 4 min | 5 min |
| Acceptance quantity | Function, integrity, no back-side ignition | Flame penetration; cold-side heat flux ≤ 2.27 W/cm² at 30.5 cm | Flame penetration; peak thermocouple temperature ≤ 204 °C at 10 cm above the upper surface of the horizontal specimen |
| Calibration heat flux | 116 ± 10 kW/m² (ISO 2685) | 18.2 ± 0.9 W/cm² | 9.1 ± 0.6 W/cm² |
| Calibration temperature | 1100 ± 80 °C (ISO 2685) | 1038 ± 56 °C | 927 ± 38 °C |
| Stand-off (cone exit to calibration plane) | 100 mm (ISO 2685); 101.6 mm (AC 20-135) | 102 ± 3 mm | 200 mm (ceiling); 50 mm (sidewall) |
| Burner attitude of the zone map | Vertical (flame upward) or horizontal axis | Burner axis 30° above horizontal, normal to the frame; frame at 30° to vertical, upper edge toward the burner (1.5.2.1, to be confirmed) | Vertical axis, flame upward |
| Zone map and parameters | Section 2.3.1.1 | [22] | [23] |

#### 1.5.1 ISO 2685 / AC 20-135 (powerplant fire)

##### 1.5.1.1 Test and calibration

| Item | ISO 2685 | AC 20-135 / AC 20-135A with SAE AS6826 |
| --- | --- | --- |
| Burner | Gas or kerosene burner; liquid-fuel burner of modified gun type in common use | Modified gun-type oil burner (Park DPL 3400 or equivalent; burner list to be confirmed against [4]); exit 152 mm × 279 mm |
| Flame temperature | 1100 °C ± 80 °C | 2000 °F (1093 °C) minimum average; individual thermocouples within ± 150 °F |
| Heat flux | 116 kW/m² ± 10 kW/m² on the standard apparatus (water-cooled copper tube) | ≥ 9.3 Btu/ft²·s (10.6 W/cm²), or 4500 Btu/h on the heat-transfer device; no upper limit |
| Distance burner to specimen | About 100 mm for the liquid-fuel burner (± 10 %) | 4 in (101.6 mm) from the burner cone exit |
| Acceptance | No flame penetration, no back-side ignition, flare-ups self-extinguishing, function maintained; elongation/dislocation where AMC 25.1193(e) applies | Same |

Values of AC 20-135 and of ISO 2685 other than temperature and flux are to be confirmed against the edition applicable to the programme (Appendix B, B15).

##### 1.5.1.2 History and status

| Item | Content |
| --- | --- |
| Two-zone model | ACTIFF, 2004 [11]; plates 254 mm × 254 mm. Presented to the authorities and accepted as a fire test substitute |
| Three-zone model | Z3 added after COMPUP, 2014 [12], larger plates. Used for all analyses (this document); the source presentation [8] recommends it for impinged surfaces of characteristic length above 400 mm |
| Status | Three-zone model to be used. Authority acceptance of the three-zone model stated per programme |
| Test/simulation comparison | COMPUP: thermocouple temperatures 400 °C to 650 °C, inclined impingement (45°) on the spar, zones extruded in the fire direction [12] |

#### 1.5.2 CS-25 Appendix F Part VII (fuselage burn-through)

##### 1.5.2.1 Test and calibration

| Item | Value (Appendix F Part VII) |
| --- | --- |
| Burner | Modified gun type (Park DPL 3400 or equivalent); Monarch 80° PL nozzle, 6.0 gal/h at 100 lb/in²; nozzle 8 mm from the exit stator; internal stator 95 mm from the nozzle tip; cone 305 mm long, exit 152 mm × 280 mm |
| Fuel | JP-8, Jet A or equivalent, 0.378 ± 0.0126 l/min |
| Intake air | 10.92 ± 0.25 m/s on an HH30A or equivalent meter (2.29 m³/min) |
| Heat flux calibration | On a separate calibration rig (Part VII (b)(3)); gauge in a 152 mm × 305 mm × 19 mm insulating block; Gardon gauge, cone exit plane 102 ± 3 mm from the gauge face, burner centreline 25.4 mm below the gauge centreline; 30 s average 18.2 ± 0.9 W/cm² |
| Temperature calibration | Seven 3.2 mm type K thermocouples, same offset; 30 s average of each 1038 ± 56 °C |
| Test arrangement | Cone exit plane 102 ± 3 mm from the outer surface of the horizontal stringers of the specimen frame; burner and test frame both at 30° to vertical (Part VII (f)(2)). Interpretation used for the zone map, not stated by the regulation text, to be confirmed against [1] Appendix F Part VII Figures 1 and 2: cone exit plane parallel to the frame; burner axis normal to the frame and 30° above horizontal; frame upper edge inclined toward the burner (burner-side face facing downward) (Figure 1) |
| Specimen | Two batt-type blankets 813 mm × 914 mm exclusive of heat-sealed film edges (rigid materials: as installed in service) on a steel frame (3.2 mm formers and stringers, centre former 6.4 mm); 12 spring clamps; at least three specimen sets; conditioned at least 24 h at 21 ± 2 °C, 55 ± 10 % RH |
| Test cell | Vertical air velocity behind the upper blanket 0.51 ± 0.25 m/s; horizontal < 0.25 m/s |
| Acceptance | No flame penetration in less than 4 min; cold-side heat flux ≤ 2.27 W/cm² at 30.5 cm from the face of the test rig (back-face Gardon gauges 102 mm from the frame vertical centreline, in the plane of the burner centreline) |

![Figure 1. CS-25 Appendix F Part VII rig: calibration plane and gauge positions; lean direction to be confirmed (1.5.2.1)](images/method_rig_partVII.png)

#### 1.5.3 CS-25 Appendix F Part III (cargo compartment liner)

##### 1.5.3.1 Test and calibration

| Item | Value (Appendix F Part III) |
| --- | --- |
| Burner | Modified gun type; 7.6 l/h (2 US gal/h) of No. 2 kerosene or equivalent (example: 80° nozzle rated 8.5 l/h at 586 kPa delivering 7.7 l/h); extension 31 cm long, opening 15 cm × 28 cm |
| Air setting | Extension removed: 7.9 m/s to 9.1 m/s at the centre of the draft tube exit (hot-wire anemometer) |
| Heat flux calibration | Gardon gauge (0–17 W/cm²) in a 15 cm × 31 cm insulating block, 20 cm from the burner cone exit, face parallel to the cone exit plane: 9.1 ± 0.6 W/cm² after 2 min warm-up |
| Temperature calibration | Seven 1.59 mm type K thermocouples: each 927 ± 38 °C |
| Test arrangement | Burner axis vertical, flame upward (calorimeter face parallel to the cone exit, simulating the horizontal specimen; thermocouple centred over the cone). Cone exit 20 cm (8 in) from the ceiling (horizontal) liner panel and 50 mm (2 in) from the sidewall (vertical) liner panel (Figure 2). Specimen in one position, insulating material in the other. Ceiling and sidewall panels may be tested individually with a baffle simulating the missing panel; a specimen passing as a ceiling panel may be used as a sidewall panel |
| Specimen | 406 ± 3 mm × 610 ± 3 mm liner panel with design features (joints, lamp assemblies); at least three specimens; conditioned at least 24 h at 21 ± 2 °C, 55 ± 5 % RH |
| Acceptance | No flame penetration within 5 min; ceiling panel: peak temperature at 10 cm above the upper surface ≤ 204 °C (thermocouple centred over the burner cone) |

![Figure 2. CS-25 Appendix F Part III rig: ceiling and sidewall calibration planes](images/method_rig_partIII.png)

## 2. Simulation method

### 2.1 Process and roles

#### 2.1.1 Global process

Process steps and thermal analysis tasks: Figure 3.

| Step | Lead / contributors | Content | Output |
| --- | --- | --- | --- |
| 1. Define the fire scenario | Fire risk lead (FESRA PRA task leader for powerplant); stress, system and thermal specialists | Scenarios to analyse; most vulnerable one (lowest RF, highest temperature, highest load redistribution) | Agreed fire scenario(s) |
| 2. Calculate structure temperature | Thermal specialist | Zone model of the burner (or calibrated model) applied to the thermal model of the structure | Temperature fields at the exposure times of the burner section |
| 3. Calculate stress fields | Stress specialist | Residual strength of the impinged structure (section 2.1.4) | RF |
| 4. Design justification | Fire risk lead | Compliance demonstration | Justification |

![Figure 3. Process and thermal analysis tasks](images/method_process.png)

#### 2.1.2 Fire scenario definition

| Role | Contribution |
| --- | --- |
| Fire risk lead (1.3.2) | Leads the activity; defines the requirements and the acceptable means of compliance |
| Design and stress specialist | For structural justification: critical areas with low RF or highest load redistribution |
| System specialist | For system specification or qualification: critical areas of the system; pass/fail criteria |
| Thermal specialist | Critical areas in terms of expected temperature versus allowable |

Objectives: maximise the local temperature at the impinged area; maximise the extent of impinged structure and the area at high temperature; maximise the heat flux to the adjacent area.

The scenario definition shall state: burner (sections 1.5 and 2.3), impingement location, burner axis direction relative to the structure, burner attitude, stand-off reference surface, exposure duration, mission and ToO (section 2.6), objective, and the acceptance criteria used downstream.

#### 2.1.3 Alignment meeting

An alignment meeting between the fire risk lead, 1ACST and the thermal specialist shall be held before modelling where the impinged geometry is non-flat or not in the calibration position, composite or other reacting material is involved, or a validity limit (sections 2.4.4, 2.8.1) is exceeded. For other analyses it should be held. It decides and records:

- the zone map on the specimen and the treatment of each non-flat feature (section 2.4);
- the escalation level of section 2.4.5 where needed;
- composite or reacting material involvement (section 2.7.6);
- the impingement locations and burner positions to analyse.

#### 2.1.4 Interface with stress

The stress process for fire [17] (powerplant example):

1. Thermal results are mapped onto the stress model at the exposure times (5 min and 15 min for ISO 2685): T_thermal per stress element.
2. For each stress element, the allowable temperature T_allowable giving RF = 1 is calculated: 100 % limit load at 5 min; get-home load (70 % limit load) at 15 min.
3. Elements with T_allowable < T_thermal are removed.
4. Stress analysis is repeated on the modified model; new allowables are calculated with local load redistribution.
5. Steps 2 to 4 are repeated until T_allowable > T_thermal for all remaining elements.
6. The final RF is verified. If not acceptable, mitigation is required (iteration between fire risk, stress and thermal).

Requirements on the thermal analysis:

- results are delivered at the exposure times of the burner section, on the stress mesh, with the NOC mapping process [19];
- the maximum mapped temperature of each impinged part is compared with the thermal model maximum; the reduction is reported, and a reduction above 20 °C is agreed with stress before use;
- where removed elements are a shield or the impinged face of an assembly, section 2.7.8 applies.

### 2.2 Zone model (all burners)

#### 2.2.1 Model form

On a face in zone i at temperature T_wall, the net heat flux density received is:

$$
\varphi_{i}(T_{wall}) = VF_{i}\,\varepsilon_{wall}\,\sigma\left(T_{ref}^{4} - T_{wall}^{4}\right) + HTC_{i}\left(T_{ref} - T_{wall}\right)
$$

| Symbol | Meaning | Source |
| --- | --- | --- |
| T_ref | Reference (flame) temperature of the burner | Burner section |
| VF_i | Equivalent grey-body view factor flame to zone i | Burner section |
| HTC_i | Equivalent convective heat transfer coefficient of zone i | Burner section |
| ε_wall | Infrared emissivity of the impinged face; 1 by default (section 2.2.3) | Section 2.2.3 |
| σ | 5.67 × 10⁻⁸ W/m²/K⁴ | — |
| N | Number of zones; zone contours in the calibration plane | Burner section |

#### 2.2.2 Identification

Each burner model is identified with the same procedure:

1. Fire test of flat plates (metallic, known thermo-optical properties) in the calibration position of the burner, with thermocouples on the plate.
2. Inverse method: incident net heat flux on the impinged face from the temperature measurements. Inputs: ambient temperature, plate thermo-optical properties, plate thermal boundary conditions (back face and edges).
3. Fit of VF_i and HTC_i of the model form of 2.2.1, per zone, on the identified flux.
4. Zone geometry chosen to fit the measured flux distribution.

Consequences for use:

- the radiative/convective split is a fit; only the total net flux as a function of T_wall is validated;
- the re-emission and convective loss of the impinged face are embedded in the fitted terms (2.2.3 item 1);
- the plate boundary conditions on back face and edges were explicit in the identification; they are explicit in every analysis (2.2.3 item 4).

#### 2.2.3 Assumptions to respect

1. **No ambient loss on impinged faces.** Impinged faces carry the zone flux only. No additional radiation or convection to ambient is applied on them. Adding it double-counts losses: for the ISO 2685 model at T_wall = 800 °C in Z1, a black face radiating to 20 °C loses about 75 kW/m², more than the 59 kW/m² net flux of the model. The rule applies per face, not per element: each shell face carries exactly one condition, zone flux or ambient/enclosure. Conduction is not a face condition. Shells impinged on both faces (2.4.3 step 5(b), 5(d), 5(e)) carry zone conductors on both faces.
2. **Emissivity of the impinged face.** ε_wall = 1, based on soot deposit from the kerosene flame. A lower value is used only with test evidence of no soot deposit on the same material and surface finish, and the result is compared with that test. A value below 1 scales a fitted radiative term and is not validated by the identification.
3. **Single reference temperature.** All zones of a burner use the same T_ref. A face without conduction or back-face loss tends to T_ref in any zone.
4. **Non-impinged faces.** Faces outside the outermost zone and faces of category K0 (back faces and enclosed faces, 2.4.3 step 5(a)) carry the ambient or enclosure condition of the scenario (section 2.5.4), with the emissivity of section 2.9.5.
5. **Flat-plate basis.** The models apply as-is to flat specimens in the calibration position. Section 2.4 defines the use on other geometry.

#### 2.2.4 Solver implementation

Per impinged face of area A: a boundary node at T_ref; a radiative conductor ε_wall·VF_i·A (σ applied by the solver) and a linear conductor HTC_i·A between the face and that node. Faces of category K3 (2.4.3 step 5(e)): 0.5·ε_wall·VF_i·A and 0.5·HTC_i·A, each not below the value of ZN. Faces of category K4 (2.4.3 step 5(b)): VF_N and HTC_N. No other boundary conductor on the impinged face. T_wall is the face temperature (surface node for solid elements). The flux depends on T_wall and is iterated within each time step. Zone conductors are applied as a step at fire onset (no ramp) and removed at the end of exposure; formerly impinged faces then carry the ambient condition with ε = 1. A scaled VF_i above 1 (sensitivities) is permitted: VF_i is a fit parameter.

#### 2.2.5 Calibration check

Before production runs, the model flux on one impinged face held at a fixed temperature is compared with the tabulated values of the burner section at two wall temperatures: 20 °C and one temperature between 700 °C and 900 °C (ISO 2685 Z1, ε_wall = 1: 116.4 kW/m² at 20 °C; 59.1 kW/m² at 800 °C). Acceptance: within 1 % of the tabulated value. The second point detects residual ambient exchange on the impinged face. The comparison of the model cold-wall flux with the burner calibration value at the gauge position is made in the identification report; a deviation larger than the calibration tolerance is stated there.

### 2.3 Burner zone models

Each subsection gives the zone map, parameters and burner-specific modelling points. Test and calibration data: section 1.5. Sections 2.2 and 2.4 to 2.10 apply.

#### 2.3.1 ISO 2685 / AC 20-135 (powerplant fire)

##### 2.3.1.1 Zone map and parameters

| Item | Value |
| --- | --- |
| Number of zones | 3 |
| Zone diameters | Z1 200 mm; Z2 400 mm; Z3 700 mm (Figure 4) |
| Vertical burner axis (flame upward) | Concentric zones centred on the burner axis |
| Horizontal burner axis | Z1, Z2 centred on the axis; Z3 centre 100 mm above the Z1/Z2 centre |
| Calibration plane | Normal to the burner axis at 100 mm from the cone exit |
| T_ref | 1373 K (1100 °C) |
| VF_i | Z1 0.38; Z2 0.19; Z3 0.095 |
| HTC_i | Z1 37; Z2 18.5; Z3 9.25 W/m²/K |
| Reference | [10] |

![Figure 4. ISO 2685 zone map for vertical and horizontal burner axis (dimensions in mm)](images/method_zones.png)

Net flux for ε_wall = 1 (kW/m², Figure 5):

| T_wall | Z1 | Z2 | Z3 |
| --- | --- | --- | --- |
| 20 °C | 116.4 | 58.2 | 29.1 |
| 500 °C | 91.1 | 45.5 | 22.8 |
| 800 °C | 59.1 | 29.6 | 14.8 |
| 1000 °C | 23.7 | 11.8 | 5.9 |
| 1100 °C | 0 | 0 | 0 |

Calibration check (2.2.5): Z1 at 20 °C gives 116.4 kW/m², equal to the ISO 2685 value of 116 kW/m². Z2 and Z3 are 1/2 and 1/4 of Z1 at any wall temperature.

![Figure 5. ISO 2685 model: net heat flux per zone versus wall temperature, ε_wall = 1](images/method_flux.png)

##### 2.3.1.2 Burner-specific points

- Hottest-zone area value: 5 in × 5 in = 16 129 mm², 51 % of the Z1 area (section 2.4.3 step 11). Origin not referenced in the source presentation [8]; to be confirmed against [2] and [4].
- Categories of 2.4.3 step 5: 0.25 D1 = 50 mm. K3 faces take the Z2 values in Z1 (58.2 kW/m² at 20 °C) and the Z3 values in Z2 and Z3.
- Validity: stand-off 100 mm ± 10 mm; vertical or horizontal axis only (other attitudes: new identification or bounding case, sections 2.4.4 and 2.4.5).

#### 2.3.2 CS-25 Appendix F Part VII (fuselage burn-through)

##### 2.3.2.1 Zone map and parameters

| Item | Value |
| --- | --- |
| Number of zones | Per identification report [22] |
| Zone contours | Per [22], in the calibration plane |
| Calibration plane | Plane of the outer surface of the frame stringers, normal to the burner axis, at 102 mm from the cone exit, inclined 30° to vertical. The regulatory burner calibration is made on a separate rig (1.5.2.1) |
| T_ref | Per [22] |
| VF_i, HTC_i | Per [22] |
| Calibration check (2.2.5) | Cold-wall flux at the point of the calibration plane 25.4 mm above the burner axis trace: compared with 182 kW/m² ± 9 kW/m² in [22] (2.2.5). Deviation between the identified flat-plate cold-wall flux and the gauge value: stated in [22] |

##### 2.3.2.2 Burner-specific points

- Typical uses: frame and stringer temperatures; heating of structure and systems behind the insulation; de-risking of blanket and fire barrier installations. Blanket degradation: section 1.1.4.
- Reference surface (2.4.3 step 3(i)): outer surface of the horizontal stringers. Formers and blankets lie behind it and take the category of 2.4.3 step 5 and the zone of their position (2.4.3 step 9).
- Acceptance quantity (cold-side heat flux): two virtual gauges, one behind each specimen, 30.5 cm from the front surface of the test frame, 102 mm either side of the frame vertical centreline, in the plane of the burner cone centreline. q = Σ_j F_g→j ε_j σ (T_j⁴ − T_amb⁴), sum over all cold-side surfaces j seen from the gauge point, gauge and cell at T_amb = 20 °C; F_g→j: view factor from the gauge point to surface j. Convection to the gauge (hot gas through openings, natural convection from the cold side) is not represented.
- The zone map is valid only in the attitude of 1.5.2.1.

#### 2.3.3 CS-25 Appendix F Part III (cargo compartment liner)

##### 2.3.3.1 Zone maps and parameters

| Item | Value |
| --- | --- |
| Zone maps | Two maps: ceiling map (calibration plane = ceiling panel at 20 cm from the cone exit) and sidewall map (calibration plane = sidewall panel at 50 mm from the cone exit, parallel to the burner axis). Cone orientation relative to the sidewall and measuring point of the 50 mm: to be confirmed against [1] Appendix F Part III Figure 1 |
| Number of zones per map | Per identification report [23] |
| Zone contours | Per [23] |
| T_ref | Per [23] |
| VF_i, HTC_i | Per [23], per map |
| Calibration check (2.2.5) | Ceiling map: cold-wall flux at the gauge position compared with 91 kW/m² ± 6 kW/m² in [23]; deviation between the identified flat-plate cold-wall flux and the gauge value: stated in [23]. Sidewall map: no regulatory calibration value; check against [23] only |

##### 2.3.3.2 Burner-specific points

- The sidewall map is a grazing-flow map at short stand-off. It is not derived from the ceiling map.
- A face inside the extruded contours of both maps takes the map giving the higher cold-wall flux. Both maps are valid only with ceiling and sidewall panels (or baffle) both present.
- Typical uses: temperature of structure, systems and equipment behind the liner; de-risking of liner design features (joints, lamp recesses). Liner degradation: section 1.1.4.
- Reference surface (2.4.3 step 3(i)): panel surface of the map.
- Acceptance quantity (ceiling): peak thermocouple temperature 10 cm above the upper surface of the horizontal specimen. A prediction requires a model of the plume above the back face; the zone model provides only the back-face temperature field. Where this quantity is needed, the method is agreed in the alignment meeting.
- Half-stand-off limits (section 2.4.4) are relative to each map: 100 mm for the ceiling map, 25 mm for the sidewall map.

### 2.4 Extension to non-flat geometry

#### 2.4.1 Status

The zone models are identified on flat plates. Their use on non-flat specimens has no identification basis. The assignment rules of 2.4.3 are recommendations; the checks, triggers and escalation route are requirements (1.1.5). Criteria: simple, conservative, model unchanged. Open points and the evidence required: Appendix B. For any specimen that is non-flat or not in the calibration position, the zone map on the specimen is confirmed in the alignment meeting (section 2.1.3) before the analysis proceeds.

#### 2.4.2 Candidate approaches

| Approach | Description | Assessment |
| --- | --- | --- |
| Cylindrical (extrusion) projection | Zone contours extruded along the projection direction; each face takes the zone it lies in | Keeps the identified variable (position in the calibration plane). Simple, reproducible, applicable to any zone shape and number. Conservative for inclined faces and faces at x > s (no reduction). Non-conservative for: structure outside the outermost contour on the buoyant or downstream side (plume, deflected jet); concave geometry (embedded loss assumes cold surroundings); small bodies and edges (local HTC above the zone value); parts at x < s. Retained as default |
| Spherical zoning | Zones defined by distance from a point on the burner axis | Implies an axial decay law not identified; reduces the zone of faces on the axis at x > s (non-conservative); no equivalent for offset or non-circular zones. Not retained |
| Test calibration (source presentation [8] "scenario 1") | Simplified test of the configuration; model parameters recalibrated | Applicable to confined or channelled flow. Calibrated parameters absorb enclosure effects and transfer only to the tested geometry. Cost and lead time. Retained as last escalation level |
| Face classes with zone increments (zone projection procedure [9]) | Nine face classes (facing, grazing, edge, closer, farther, hidden, cavity, wrap-around, outside) with ±1 zone rules | "One zone" has no generic meaning for N zones and other burners; edge and proximity increments arbitrary; hidden-face reduction non-conservative under flanges (recirculating hot gas); not reproducible between analysts. Not retained. The ZN flux on back faces reached by the flame (2.4.3 step 5(b)), the run with the feature on the axis (step 10) and the validity limits (2.4.4) are kept. Hidden-face reduction retained only for open-wake faces of parts between 0.25 D1 and D1, as a factor on the zone of position (2.4.3 step 5(e)) |

#### 2.4.3 Default procedure

1. **Zone map.** Use the zone map of the burner section in its identified attitude relative to gravity. The map is fixed to the burner and gravity, not to the specimen.
2. **Projection direction.** Normal to the calibration plane of the map: the burner axis for ISO 2685 and Part VII and for the Part III ceiling map; normal to the sidewall for the Part III sidewall map.
3. **Burner position.** Burner axis, direction and stand-off as defined by the scenario. The stand-off is the distance from the cone exit plane to the reference plane. Reference surface: (i) as fixed by the test standard or the scenario (burner-specific points of section 2.3); (ii) where not fixed, the burner-facing surface nearest to the burner whose projection covers at least 50 % of the area enclosed by the hottest-zone contour; (iii) where no surface meets (ii), the burner-facing face of the governing part nearest to the burner.
4. **Assignment.** Every face inside the outermost contour takes one category of step 5 (Figure 6). Zone of position: zone of the extruded contour containing the face. Contours are extruded from the cone exit plane in the flame direction, without limit of distance. The flux is applied on the true face area. No reduction is applied for inclination or distance; no increment for edges or proximity. An element straddling a contour takes the hotter zone; an element straddling a category boundary takes the category of higher flux.
5. **Categories.** Edges and openings are located relative to the extruded contours. The tests are applied in the order (a) to (e); the first that applies governs.
   - (a) K0, not impinged: face in a sealed volume; back face of a wall, or face behind a wall, where the wall has no free edge and no opening inside the hottest-zone contour. Ambient or enclosure condition (2.5.4), as in the identification (2.2.2). Free edge or opening between the hottest-zone and outermost contours: recorded (B4).
   - (b) K4, behind a wall: back face of a wall, or face behind a wall, where the wall has a free edge or opening inside the hottest-zone contour. ZN flux on the area inside the outermost contour.
   - (c) K1, visible: face with θ ≤ 100° from which the line along the projection direction toward the cone exit plane meets no part. Zone of position.
   - (d) K2, wrapped: hidden face with b < 0.25 D1; hidden face inside a cavity of step 8 or facing another impinged face at a distance below b; hidden face at a distance above b behind the shadowing part. Zone of position.
   - (e) K3, sheltered: other hidden faces (0.25 D1 ≤ b < D1). Zone of position with VF_i and HTC_i multiplied by 0.5, not below the ZN values (2.2.4).
6. **Hidden faces.** Hidden face: face inside the outermost contour, not visible under 5(c) and not under 5(a) or 5(b). Shadowing part: the part met first by the line of 5(c); for a face with θ > 100°, the part carrying the face. Parts joined without opening count as one part. b: smallest dimension of the outline of the shadowing part projected on the calibration plane, at the section containing the face. A shadowing part with b ≥ D1 is a wall (1.3.2); its back face and the faces behind it are under 5(a) or 5(b). Face-to-face radiation is not added on K2 and K3 faces (S11, 2.8.4).
7. **Edges and protrusions.** No specific rule. Edge faces take the category of step 5. The mesh resolves the edge.
8. **Cavities.** Cavity: concave feature whose opening lies inside the outermost contour, whatever the orientation of the opening, with internal faces impinged under step 5. w = smallest dimension of the opening; d = largest distance from the opening plane to an internal face, normal to that plane. d < 0.25 w: not a cavity; steps 4 to 6 apply. 0.25 w ≤ d ≤ w: all internal faces take the lowest-numbered zone crossing the opening, without the factor of 5(e); face-to-face radiation is not added in the nominal case (S11, section 2.8.4). d > w: section 2.4.4. A closed section open only at its ends (hat stringer, tube, box) is treated by step 5(a) or 5(b), not as a cavity.
9. **Faces closer to or farther from the burner than the reference plane** (x < s or x > s): category of step 5 and zone of position, within the limits of 2.4.4.
10. **Positions.** Where the scenario does not fix the burner position relative to the critical feature: (i) feature on the burner axis (objective: local temperature); (ii) positions named in the scenario; (iii) where the objective is the extent of heated structure or the flux to an adjacent part (2.1.2), the axis midway between the feature and that part. The governing case is identified per objective. Positions with the feature on a zone boundary are not required. Positioning tolerance is covered by sensitivity S3 (section 2.8.4), not by enlarging zones.
11. **Hottest-zone area check.** Area of the calibration plane inside the hottest-zone contour covered by the projection of impinged faces ≥ reference value: ISO 2685, 16 129 mm² (5 in × 5 in, 51 % of the Z1 area; source value, 2.3.1.2); other burners, 50 % of the hottest-zone area, pending [22], [23]. If not met: (i) isolated narrow part: no change of the assignment; recorded; (ii) Z1 contour partly off the structure (edge, opening): burner position per step 10 unless fixed by the scenario; recorded. Zones are not enlarged. A failed check is reported to the alignment meeting (2.4.4).
12. **Documentation.** Zone map on the specimen (figure with zones coloured), list of faces per category K2, K3, K4 and under step 8, positions run, checks of 2.4.4.

Known simplifications.

- Conservative: outer zones applied where the real flow has no wall jet; inclined footprints receive 1/cos θ more power than a flat plate; grazing faces carry the zone flux over their full depth; hidden faces carry no loss to ambient and tend to T_ref; hidden faces of parts below 0.25 D1 and pocket faces carry the full zone flux; rule 5(b) removes all loss from the wall.
- Non-conservative, not corrected in the nominal case: K3 flux at wall temperatures below about 400 °C for b near 0.25 D1 (S12); step 8 ignores re-radiation (S11); small-body and leading-edge convection above the zone HTC (S10); faces at 0.5 s ≤ x < s (B1); rule 5(a) with a free edge between the hottest-zone and outermost contours (B4); non-impinged faces receive no flame radiation and no hot-gas convection (B7); stagnation-point shift (B2).
- The factor 0.5 of 5(e) is a judgement value based on rear-face convection of bluff bodies; not identified (B17).

![Figure 6. Cylindrical (extrusion) projection; burner cone schematic, not to scale](images/method_projection.png)

#### 2.4.4 Limits and escalation triggers

Notation: s = stand-off of the map; D1, b, θ (1.3.2); w = smallest dimension of the cavity opening; x = distance from the cone exit plane along the projection direction of the map.

| Trigger | Action |
| --- | --- |
| Scenario stand-off outside s ± tolerance of the burner section | Zone map applied unchanged at the scenario stand-off; recorded. Outside 0.5 s to 2 s: bounding case or test calibration |
| Narrow part or protrusion with a face at x < 0.5 s | Test calibration, or bounding case with CFD support |
| Narrow part or protrusion with a face at 0.5 s ≤ x < s | Projection; recorded (open point B1) |
| Face at x > 2 s, inside the outermost contour | Projection; recorded (open point B1) |
| Grazing face deeper than 2 s along the projection direction | Projection; recorded (open point B1) |
| K3 face (2.4.3 step 5(e)) on a part whose governing temperature is below 400 °C at the exposure time | S12 (2.8.4) included in the nominal case |
| Continuous reference surface inclined to the calibration plane, with portions at x < 0.5 s or x > 2 s | The inclination rows apply; the three rows above do not (open point B11) |
| Structure outside the outermost contour, above the flame on the buoyant side, or at x > 2 s on the downstream side | Bounding case agreed in the alignment meeting (outermost-zone flux extended to that structure). No general widening of zones |
| Inclination of the reference surface to the calibration plane above 45° | Alignment meeting |
| Inclination of the reference surface to the calibration plane above 70°, or flame channelled along the structure | Bounding case or test calibration |
| Cavity depth between 1 w and 3 w | Projection per 2.4.3 step 8 with the S11 added flux included in the nominal case |
| Cavity depth above 3 w; passage with inlet inside the hottest-zone contour and a separate outlet through which the flame is channelled; free section smaller than the cone exit area | Test calibration |
| Part dimension below 0.25 D1 that governs the result | HTC sensitivity (S10, section 2.8.4) or bounding case |
| Hottest-zone area check failed | 2.4.3 step 11 case (i) or (ii); alignment meeting |
| Burner attitude relative to gravity different from the identification | New identification, or bounding case |
| Reacting or receding impinged surface | Outside the model (section 2.7.6) |

The ISO 2685 / AC 20-135 cone exit (152 mm × 279 mm) is wider than D1 in one direction. At s = 100 mm, a plate inclined about the short axis of the cone exit meets the cone lip at about 36° (about the long axis: 53°), before the inclination rows are reached.

#### 2.4.5 Escalation levels

| Level | Method | Use |
| --- | --- | --- |
| 1 | Projection (2.4.3) | Default |
| 2 | Bounding case without test, defined per trigger of 2.4.4 and recorded. Default: Z1 flux on all impinged faces of the feature. Cavities, channels and faces facing hot walls: Z1 flux with the S11 added flux in the nominal case. Upper bound of the model: faces of the feature at T_ref + δT from fire onset | When a trigger of 2.4.4 applies. If the bounding case meets the acceptance criterion, no further level is required. T_ref is a thermocouple temperature: in confined or channelled flow the face temperature is not bounded by T_ref; level 4 applies |
| 3 | CFD support | To rank configurations and to choose the bounding case. CFD fluxes are not used as certification boundary conditions unless agreed with the authority |
| 4 | Test calibration | Confined or channelled flow (example [13]: rear engine mounts, box in refractory material with the titanium part). The calibrated parameters and their geometric range of validity are documented |

### 2.5 Toolset and model architecture

#### 2.5.1 Toolset

| Function | Tool (to be completed by the thermal team, with versions) |
| --- | --- |
| Thermal solver (transient conduction, radiation) | — |
| Pre-processor / mesher | — |
| Radiation view-factor module | — |
| Zone projection and zone colouring | — |
| Local model boundary conditioning from global model | STT008 [21] |
| Mapping to stress model | NOC mapping process [19] |
| Post-processing and report | Thermal Analysis Report Template [19] |

The tool and version used for each function are stated in the analysis report.

#### 2.5.2 Global model and local model

The thermal model extends beyond the area affected by the fire, so that the location of the cut-off boundary conditions does not influence the thermal field in the area of interest. The fire thermal model should be derived from the global thermal model of the zone, refined in the area of interest. Where refinement of the global model is not feasible (memory, solve time), a local refined model is built and its boundaries are conditioned with global model results (Figure 7):

| Step | Action | Check |
| --- | --- | --- |
| 1 | Run the global model in NOC and in fire conditions, with the same zone flux and burner position as the local run | Global NOC model validated per [19] |
| 2 | Prescribe the local model cut boundary conditions from the global NOC results | — |
| 3 | Run the local model in NOC | Local NOC results agree with global NOC results in the area of interest; deviations reported |
| 4 | Update the local model cut boundary conditions with the global fire results (non-impinged boundaries) | — |
| 5 | Run the final fire simulation with the updated local model | — |

![Figure 7. Global and local model process](images/method_global_local.png)

Precondition: a global model exists or is planned. For numerical reproduction of a fire test, a local model of the specimen and its test fixture is used.

#### 2.5.3 Cut boundary placement

- Cut boundaries lie outside the outermost contour.
- Cut boundaries should be placed where the global fire calculation shows a temperature rise at the end of exposure not exceeding 5 % of the rise in the area of interest, or 10 °C, whichever is larger.
- A run with the cut boundary moved outward, or with prescribed temperature replaced by adiabatic, shall be performed where the nominal margin is below 100 °C (section 2.8.5).

#### 2.5.4 Initial and boundary conditions

| Item | Rule |
| --- | --- |
| Initial temperature field | Installed-part analysis: transient field at the ToO (section 2.6). Test reproduction: test conditions |
| Impinged faces | Zone flux only (section 2.2.3) |
| Non-impinged faces | Ambient convection and radiative environment of the scenario, as in the NOC model of the same operating phase, unless the scenario defines a fire-zone environment |
| Internal cavities and enclosures | Internal radiation (enclosure) and natural convection |
| Conditions after fire onset | Stated in the report (section 2.6.3) |

### 2.6 Initial conditions, mission and time of occurrence

#### 2.6.1 General

The initial temperature field and the conditions after fire onset are taken from the operating phase defined by the scenario. A uniform initial temperature is not used for installed-part analyses.

| Burner | Typical operating phase |
| --- | --- |
| ISO 2685 / AC 20-135 | Flight or ground, engine/APU operating then windmilling or stopped (AMC 25.1193(e)); section 2.6.2 |
| Appendix F Part VII | Ground, post-crash: aircraft static, no external airflow, systems off; initial field per scenario |
| Appendix F Part III | Flight (cruise or descent) or ground, per cargo fire scenario |

#### 2.6.2 Powerplant: mission and ToO

- Thermal mission: Allowable Maximum Hot Day (AMHD) [18], except for test reproduction. Rationale stated in the source presentation [8]: the ISO 2685 and AC 20-135 burners are considered to represent a maximum hot-day environment.
- ToO, chosen to maximise the temperature in the area of interest at the end of the exposure (15 min for primary structure; 5 min for a fire-resistant target):
  1. run the NOC transient without fire over the mission;
  2. identify the instant of maximum NOC temperature in the area of interest;
  3. set the fire onset 15 min (or 5 min) before that instant.
- Applies to parts whose NOC temperature peaks in cruise (example: A380 EA/RR forward engine mount shackles [16]). For pylons, the fire is placed in the second mission of the cyclic mission.
- Where the NOC temperature of the area of interest at the fire onset defined above is more than 30 K below its maximum, a second case with fire onset at the NOC maximum should be run (highest initial temperature; governs the 5 min result). The more severe result at each exposure time governs.

#### 2.6.3 Conditions after fire onset

- Powerplant (AMC 25.1193(e)): flight, engine/APU operative for the first 5 min, then 10 min windmilling (engine) or stopped (APU), external airflow credit allowed; ground, engine/APU operative 5 min then stopped 10 min, requirement applied with the engine operating or not operating, whichever is more critical, operating conditions justified by the applicant (AMC 25.1193(e)(3)(i)(C)), no airflow credit. AMC 25.1193(e) is written for cowling, nacelle and APU compartment skins; for other structure the conditions are set by the scenario.
- Where the scenario does not fix them, the conditions giving the higher temperature in the area of interest shall be used.

### 2.7 Points of attention specific to fire

#### 2.7.1 Impinged-face boundary condition

Section 2.2.3 items 1 and 2. The solver set-up is checked so that each shell face carries exactly one condition (zone flux or ambient/enclosure) and no other exchange exists on impinged faces. Inside cavities, channels or facing hot walls, the real net flux at high wall temperature is higher than the model (embedded loss assumes cold surroundings): section 2.4.4. S11 without the limit at T_ref has no equilibrium (net flux of 40 kW/m² to 160 kW/m² at T_wall = T_ref for F between 0.8 and 0.2, ISO 2685 Z1).

#### 2.7.2 Back faces

The equilibrium temperature of thin impinged parts is set by the back-face loss. Example (ISO 2685, Z1, thin plate, back-face natural convection 10 W/m²/K to 20 °C): about 740 °C with back-face emissivity 1, about 900 °C with 0.3. Back-face radiation is modelled as an enclosure exchange with view factors where surrounding structure is in the area of interest. The nominal back-face emissivity is the lower bound (2.9.5); S4 and S5 (2.8.4) cover the remaining uncertainty.

#### 2.7.3 Flux steps at zone boundaries

The zone flux is discontinuous at zone contours and at the outermost contour. The in-plane gradient across these contours is not a physical gradient. Its use for thermal stress requires agreement of the thermal specialist.

#### 2.7.4 Temperature ceiling

A part without conduction or back-face loss tends to T_ref in any zone. Not validated for thin or insulated parts in Z2 to ZN. Assessed conservative; no test evidence.

#### 2.7.5 Exposure end

Exposure stops at the exposure duration of the burner section. Where adjacent parts peak after the end of the fire (soak-back), the run is continued after extinction with the post-fire conditions of the scenario.

#### 2.7.6 Composite and other reacting materials

Composite behaviour under fire:

- resin decomposition and flammable gas release;
- internal gas pockets and pressure: delamination, matrix cracking;
- combustion of the gas at the impinged surface: added heat flux;
- gas diffusion to the back face of a firewall and ignition: loss of containment.

The zone models are not usable as-is for composite material directly impinged, or able to contribute to the fire by flammable outgassing. Modelling approaches used for the A350 Section 19 firewall removal [14] and the A321XLR [15] require test data as input. For a fire analysis where composite material is impinged or predicted above the temperature limit given by 1ACST for the material, 1ACST shall be contacted before modelling. The same applies to liner panels (Part III) and insulation blankets and films (Part VII). Paint, sealant, primer and blankets on impinged faces are recorded in the report.

#### 2.7.7 Metallic materials at high temperature

| Material | Point of attention |
| --- | --- |
| Aluminium alloys | Solidus below the flame temperature (value from the material data source). Above the solidus the part is lost: the structure behind it is exposed by re-projection (section 2.7.8) and the result is reported as burn-through |
| Titanium | β-transus near 1000 °C. Not fireproof by definition for the FAA (section 1.4.3.1) |
| Stainless steel, Inconel | Fireproof by definition at ≥ 0.4 mm; analysis needed for function or load capability |
| All | k, cp, ρ, emissivity tabulated up to at least T_ref of the burner (1100 °C for ISO 2685), with source and extrapolation stated |

#### 2.7.8 Removal of parts

Where a part melts or where stress removes elements that are a shield or the impinged face of an assembly, a second thermal run with re-projection of the zones on the exposed structure shall be performed from the time of loss, unless the thermal and stress specialists record that the structure behind is not affected.

#### 2.7.9 Internal fluids and active cooling

Parts carrying fuel, oil, hydraulic fluid or air flow require explicit modelling of the internal side. The zone model gives only the external impinged-face condition.

### 2.8 Validity, limitations, uncertainty and margins

#### 2.8.1 Range of validity

| Parameter | Validated range / basis | Outside the range | Action | Data source in case of doubt |
| --- | --- | --- | --- | --- |
| Flame | Burner of the burner section, within its calibration tolerance | Other flames not represented | Not covered (1.1.4) | [2], [4], [1] App. F |
| Stand-off | Calibration stand-off ± tolerance of the burner section | Section 2.4.4 | Section 2.4.5 | Identification report ([10], [11], [12], [22], [23]) |
| Burner attitude | Attitude of the identification (burner section) | Buoyant deflection not identified | New identification or bounding case | Identification report ([10], [11], [12], [22], [23]) |
| Geometry | Flat plate in the calibration plane | Non-flat: section 2.4 | Section 2.4.5 | [12], [13] |
| Specimen size | Plate sizes of the identification (ISO 2685: 254 mm × 254 mm for two zones; larger plates for three zones) | Heating beyond the outermost contour not identified | Section 2.4.4 | Identification report ([10], [11], [12], [22], [23]) |
| Hottest-zone area | Section 2.4.3 step 11 | Less than the reference area of the hottest zone (Z1) covered | 2.4.3 step 11 case (i) or (ii); alignment meeting | [2], [4] |
| Impinged material | Metallic, non-reacting | Heat release and outgassing not represented | 1ACST (2.7.6) | [14], [15] |
| Impinged face emissivity | 1 (soot) | ε < 1 not validated | Test evidence only (2.2.3) | Test report, same material and finish |
| Exposure | Exposure duration of the burner section | Soak-back not covered by the identification | Continue run after extinction (2.7.5) | — |
| Wall temperature | ISO 2685: test/simulation comparison 400 °C to 650 °C [12]; identification range: to be completed | Near T_ref the net flux is the difference of large terms | S2 is run for every analysis (2.8.4). Above the compared range the result is stated as extrapolated. Maximum temperature of the model bounded by T_ref | [11], [12], [22], [23] |
| Material data | Up to at least T_ref | Extrapolated properties | State extrapolation; sensitivity S9 | Programme material data |

#### 2.8.2 Limitations

Stated in every analysis report:

1. The models are fitted on flat plates in the calibration position. The radiative/convective split is a fit; only the total net flux as a function of wall temperature is validated.
2. Zone contours are flux steps, not measured gradients. In the ISO 2685 model, Z2 and Z3 are scaled copies of Z1 (1/2 and 1/4).
3. All zones share T_ref; the equilibrium temperature without losses is T_ref in every zone.
4. Extrusion projection does not represent the stagnation-point shift and wall-jet asymmetry under oblique impingement, jet widening downstream, or plume extension beyond the outermost zone.
5. Mutual radiation between impinged faces in concave geometry and the higher HTC at small bodies and edges are not represented.
6. Decomposition, combustion of outgassed volatiles, and heat release from coatings, liners and blankets are not represented.
7. Burn-through, melting and removal of parts are represented only by re-projection (2.7.7, 2.7.8).
8. Surfaces outside the outermost zone receive no flame radiation, no hot-gas convection and no radiation from the flame-side face of impinged parts.
9. Part III and Part VII acceptance quantities (peak thermocouple temperature above the horizontal specimen, cold-side heat flux) are not direct model outputs (2.3.2.2, 2.3.3.2).

#### 2.8.3 Uncertainty sources

| Source | Magnitude | Main influence |
| --- | --- | --- |
| Burner flux tolerance | ISO 2685: ± 10 kW/m² (± 8.6 %); Part VII: ± 0.9 W/cm² (± 4.9 %); Part III: ± 0.6 W/cm² (± 6.6 %) | Heating rate, thick parts |
| Burner temperature tolerance | ISO 2685: ± 80 K; Part VII: ± 56 K; Part III: ± 38 K | Equilibrium temperature, thin parts |
| Stand-off tolerance | Burner section | Not quantified separately; assumed covered by S2 |
| Burner lateral position | ± 10 mm default | Position of Z1 relative to critical feature |
| Identification (inverse method, assumed shape) | ± 10 % to ± 15 % on net flux (assumed; no value in [11]), larger at high wall temperature | All |
| Small-body and edge convection | Local HTC above the zone value; order of 1.5 × for a Ø25 mm tube in Z1 of ISO 2685 (engineering judgement) | Small parts |
| Back-face emissivity | ± 0.1 to ± 0.2 | Equilibrium temperature of thin parts |
| Conductivity, specific heat at high temperature | k ± 10 %; cp ± 5 % to ± 10 % | Gradients, heating rate |
| Thickness and mass | Drawing tolerances | Heating rate |
| Contact conductance | Factor 3 to 10 | Heat sinking to attached parts |
| Initial temperature field | NOC model accuracy [19] | Initial state |

#### 2.8.4 Sensitivity set

δq = relative flux tolerance and δT = temperature tolerance of the burner (2.8.3).

| ID | Sensitivity | Definition |
| --- | --- | --- |
| S1 | Withdrawn | Bounded by S2 at every wall temperature above 20 °C |
| S2 | Flux and reference temperature, upper tolerances | T_ref + δT, with VF_i and HTC_i scaled so that the hottest-zone cold-wall flux equals (1 + δq) × nominal (ISO 2685: T_ref = 1453 K, factor 0.911, 126.4 kW/m²) |
| S3 | Position | Zone map shifted by the positioning tolerance (2.8.3) in the direction that raises the temperature of the governing location. Not applicable where the governing location and all structure within the tolerance of a zone contour keep their zones; stated in the report |
| S4 | Back-face emissivity | Impinged part: nominal value − 0.1 where the nominal value is a measured lower bound; otherwise −0.2 |
| S5 | Back-face emissivity, high | Neighbouring parts receiving radiation from the impinged part |
| S6 | Contact conductance, low | Impinged part: nominal ÷ 3 (÷ 10 where the nominal value is not measured) |
| S7 | Contact conductance, high | Attached parts: nominal × 3 (× 10 where not measured) |
| S8 | Thermal mass | Minimum thickness; cp − 10 % |
| S9 | Thermal conductivity | k ± 10 %, sign adverse for the governing part |
| S10 | Small-body HTC | HTC_i × 1.5 × (25 mm / d)^0.5, not below 1.5, on parts of dimension d below 0.25 D1 (2.4.4) |
| S11 | Cavity re-radiation | Cavity faces (2.4.3 step 8): added absorbed flux ε_wall σ T_wall⁴ (1 − F_face→opening) for T_wall < T_ref; added flux set to zero for T_wall ≥ T_ref. F_face→opening: view factor from the face to the plane of the cavity opening. Implemented as a heat load tabulated versus T_wall. The face temperature is then bounded by T_ref |
| S12 | Sheltered faces | Factor of 2.4.3 step 5(e) set to 1: K3 faces take VF_i and HTC_i of the zone of position |

Note: T_ref + δT at unchanged VF and HTC (ISO 2685: 139 kW/m²) lies outside the flux tolerance.

Scope: S2 and S3 shall be run for every analysis. S4 to S12 and the combined case shall be run where the nominal margin is below 100 °C (2.8.5); otherwise they should be run.

Combined case: S2; S3; for each pair S4/S5 and S6/S7 the member adverse for the governing part; S8; S9; S10, S11 and S12 where applicable.

Test reproduction: S2 is replaced by a run scaled to the calibration flux and temperature recorded for the test.

Reporting: nominal result, delta of each sensitivity, root-sum-square of the positive deltas of the combined-case selection (information only; the decision of 2.8.5 uses the combined case), and combined case, at each exposure time.

#### 2.8.5 Margins and decision

Margin = T_allowable − T_predicted at the governing location of each part, at each exposure time. T_allowable: for structure, the temperature giving RF = 1 under the load of the exposure time on the unmodified stress model (2.1.4 step 2), supplied by stress; for systems and equipment, the limit of the specification. Where T_allowable is not available when the thermal analysis is run, S2 to S12 and the combined case are run and delivered with the nominal result.

| Row | Result at any exposure time | Decision |
| --- | --- | --- |
| 1 | Nominal above the allowable | Mitigation, redesign or test |
| 2 | Nominal below the allowable; S2, S3 or the combined case above the allowable | Alignment meeting; decision: test, test calibration, bounding case or mitigation |
| 3 | Nominal margin between 0 and 100 °C, or allowable strength changing by more than 10 % per 50 °C at the predicted temperature; all cases below the allowable | Alignment meeting; decision recorded |
| 4 | Nominal margin ≥ 100 °C; S2 and S3 below the allowable | Analysis result used as is |

Rows are tested from top to bottom; the first that applies governs. The 100 °C threshold is a default, to be confirmed by 1ACST (Appendix B, B16). Until confirmed, 100 °C applies. The alignment meeting may set another value for a programme. For heat-flux acceptance quantities (Part VII), the margin is expressed on the quantity and the threshold is set in the alignment meeting.

#### 2.8.6 Outside the range of validity

1. Record the parameter outside the range and the magnitude of the exceedance.
2. Alignment meeting.
3. Escalation level of section 2.4.5: bounding case first (level 2, with CFD support, level 3, where needed); test calibration (level 4) where the bounding case does not meet the criterion.
4. CFD may support the definition of a test or of a bound; it does not replace test calibration unless agreed with the authority.

### 2.9 Modelling requirements

The NOC thermal modelling guidelines [20] apply. The following requirements are specific to fire analysis.

#### 2.9.1 Mesh

| Item | Requirement |
| --- | --- |
| Refinement | Refined on impinged and adjacent parts |
| Gradient criterion | Target: temperature difference between adjacent elements ≤ 20 °C, checked at the time of maximum gradient (early transient). Element pairs across a zone contour or the outermost contour are exempt (2.7.3). Exceedances are listed and justified by a mesh-convergence run |
| Through-thickness | Solid elements where the through-thickness temperature difference q·t/(2k) exceeds 20 °C (q: absorbed flux density; t: thickness; k: thermal conductivity). With q = 116 kW/m² (ISO 2685 Z1): shells acceptable up to about 2.4 mm for titanium alloys (k ≈ 7 W/m/K), 5 mm for austenitic stainless steel (k ≈ 15 W/m/K), 3.5 mm for Inconel 625/718 (k ≈ 10 W/m/K to 11 W/m/K), 50 mm for aluminium alloys. Room-temperature k; k increases with temperature. For other burners, use the hottest-zone cold-wall flux of the burner |
| Element quality | Distortion criterion > 0.7 (metric of the solver used, named in the report) |
| Zone contours | Impinged surfaces split along the projected zone contours before meshing |
| Positioning sensitivity | Shifted contours built into the geometry or the mesh regenerated |

#### 2.9.2 Time integration

- Initial heating rate of a thin impinged sheet: q/(ρ·cp·t) (q as in 2.9.1). ISO 2685 Z1: about 47 K/s for 1 mm titanium, about 70 K/s for 0.4 mm stainless steel.
- Time step at fire onset ≤ 0.2 s for impinged thickness ≥ 1 mm, ≤ 0.1 s below 1 mm, with adaptive stepping limiting the temperature change per step to 20 °C on impinged elements. For burners with higher flux (Part VII), the step is reduced in proportion. The limit applies until the adaptive criterion (20 °C per step on impinged elements) allows a larger step.
- Time-step convergence checked once per model: halving the time step changes the peak temperatures at the exposure times by less than 1 % of the temperature rise since fire onset.

#### 2.9.3 Material properties

Tabulated to at least T_ref of the burner; phase transformations (titanium β-transus, aluminium solidus) included in specific heat where data exist; source and extrapolated range stated.

#### 2.9.4 Thermal mass

Thermal inertia checked against the real mass of each part in the area of interest. Mass represented locally; non-structural or lumped mass is not smeared onto impinged elements (added mass in the hottest zone is non-conservative).

#### 2.9.5 Thermo-optical properties

| Surface | Emissivity |
| --- | --- |
| Impinged faces | ε_wall = 1 (2.2.3) |
| Back face of impinged parts, and any non-impinged face whose radiative loss lowers the temperature of the governing part | Lower bound of the emissivity range of the material and surface state at temperature; value and source stated |
| Other non-impinged faces | End-of-life emissivity |
| Formerly impinged faces after the end of exposure | ε = 1 (2.2.4) |

#### 2.9.6 Contacts, joints and enclosures

- Contact conductances bounded in both directions (S6, S7). Joint opening under thermal expansion is not modelled; where a joint carries more than 10 % of the heat leaving the impinged part, the low bound is used in the nominal case.
- Enclosure radiation behind impinged parts modelled with view factors.
- Radiation between impinged faces in concave geometry: excluded by default (2.4.3 step 8; S11, 2.8.4); inclusion stated in the report.

#### 2.9.7 Verification checks before production runs

The following checks shall be performed before production runs.

| Check | Acceptance |
| --- | --- |
| Calibration check (2.2.5) | Within 1 % of the tabulated flux at both wall temperatures |
| One condition per shell face (zone flux or ambient/enclosure) | Verified on a test element |
| No ambient exchange on impinged faces | Verified in the boundary condition set-up |
| Energy balance | Absorbed = stored + losses, within 1 % of the absorbed energy |
| Mesh gradient criterion | 2.9.1 |
| Time-step convergence | 2.9.2 |
| Local model against global NOC | 2.5.2 step 3 |

### 2.10 Verification, post-processing and reporting

#### 2.10.1 Validation

- The NOC thermal model validation approach of [19] applies.
- Where fire test data exist for the configuration, measured and predicted temperatures are compared at each thermocouple over time; deviations at the exposure times and the maximum deviation are reported.

#### 2.10.2 Post-processing

The report uses the visual identity of the Thermal Analysis Report [19] and contains:

1. Images of the mesh around the impinged area, with faces of each zone in a distinct colour, and the faces per category K2, K3, K4 (2.4.3 step 5) and the faces under 2.4.3 step 8 identified.
2. The hottest-zone area check.
3. Plots over time of the average, maximum and minimum temperature of each impinged part.
4. A table of these temperatures at each exposure time (ISO 2685: 5 min and 15 min; Part VII: 4 min; Part III: 5 min).
5. Temperature field images at each exposure time.
6. For thick parts, the field at the time of maximum thermal gradient, if requested by stress.
7. The acceptance quantity of the burner section where applicable (Part VII cold-side heat flux; Part III per alignment meeting).
8. The sensitivity results (2.8.4) and the margin decision (2.8.5).

#### 2.10.3 Delivery to stress

Section 2.1.4.

#### 2.10.4 Documentation checklist

- [ ] Burner and identification report used; calibration check (2.2.5)
- [ ] Scenario: impingement location, burner attitude, reference surface, exposure duration, objective, acceptance criteria (2.1.2)
- [ ] Alignment meeting record (2.1.3)
- [ ] Toolset and versions (2.5.1); model architecture and cut boundaries (2.5.2, 2.5.3)
- [ ] Initial field, mission, ToO, post-onset conditions (2.6)
- [ ] Zone map on the specimen; faces per category K2, K3, K4 identified (2.4.3 step 5); faces under 2.4.3 step 8; positions run (2.4.3)
- [ ] Hottest-zone area check (2.4.3 step 11)
- [ ] Triggers of 2.4.4 checked, one line each; escalation level used (2.4.5)
- [ ] Validity table checked, one line each (2.8.1)
- [ ] Emissivity per surface with justification (2.9.5)
- [ ] Material property sources and extrapolation (2.9.3)
- [ ] Verification checks (2.9.7)
- [ ] Sensitivities, combined case, margin decision (2.8.4, 2.8.5)
- [ ] Limitations stated (2.8.2)
- [ ] Departures from this method, with justification (1.1.5)

## Appendix A. Projection examples (ISO 2685 burner)

Zone radii 100 / 200 / 350 mm (section 2.3.1.1); s = 100 mm; D1 = 200 mm (1.3.2). Burner axis normal to the reference surface, vertical-axis map, centred on the critical feature unless stated. Assignment per section 2.4.3; categories K0 to K4 per 2.4.3 step 5; r is the radial distance from the burner axis.

### A.1 Stiffened skin, smooth side toward the burner

3 mm skin, 500 mm × 500 mm, Z-stringers at 150 mm pitch on the far side; skin at the reference surface.

| Surface | Category | Zone / condition |
| --- | --- | --- |
| Skin, flame side | K1 | Z1 (r ≤ 100), Z2 (100–200), Z3 (200–350); corners beyond r = 350 mm: not impinged |
| Skin back face, stringers | K0 | Panel edges at r ≥ 250 mm, outside the hottest-zone contour: 2.4.3 step 5(a); ambient or enclosure condition. Free edges inside the outermost contour: recorded (B4) |

Hottest-zone area 31 416 mm²: pass. Panel edge mid-points at r = 250 mm (Z3); corners 4 mm outside Z3. The edge condition (free or sealed) is recorded.

### A.2 Stiffened skin, stringer side toward the burner

Same panel turned; Z-stringers 25 mm high, 20 mm free flange; reference surface: skin (2.4.3 step 3(ii); the free flange covers 13 % of the hottest-zone area).

| Surface | Category | Zone / condition |
| --- | --- | --- |
| Axial stringer: free flange top, edges, open web side, attached flange | K1 | By position along the stringer, Z1 for \|y\| ≤ 100 mm, Z2 to 200 mm, Z3 to the panel edge |
| Stringers at 150 mm offset, same faces | K1 | Z2 for r ≤ 200 mm, then Z3 |
| Skin between stringers | K1 | By position |
| Pocket under the free flange (underside of free flange, shadowed web side, skin strip under the flange; d/w = 0.8) | K2 (2.4.3 step 5(d): b = 20 mm; cavity) | Cavity (2.4.3 step 8): lowest-numbered zone crossing its opening; S11 where 2.8.4 requires |
| Skin far side | K0 | As A.1: not impinged |

In this table y is the distance along the stringer from the burner axis. Free flange at x = 0.75 s: protrusion, projection, recorded (2.4.4). Hottest-zone area: pass. Positions (2.4.3 step 10): stringer on the axis; bay centre on the axis (named position). The governing case is identified per objective.

### A.3 Hat stringer toward the burner

30 mm high, crown 25 mm, webs at 70° to the skin; reference surface: skin (crown covers 16 % of the hottest-zone area).

| Surface | Category | Zone / condition |
| --- | --- | --- |
| Crown, corners, webs, feet, skin | K1 | By position |
| Inside of the closed hat | K0 or K4 | Hat ends closed, or outside the outermost contour: K0 (2.4.3 step 5(a)), conduction and internal radiation. Hat end open inside the hottest-zone contour: K4 (2.4.3 step 5(b)), ZN flux. Hat end open between the hottest-zone and outermost contours: K0 (2.4.3 step 5(a)), not impinged, recorded (B4) |
| Skin far side | K0 | As A.1: not impinged |

Crown at x = 0.70 s: projection, recorded (2.4.4). Hottest-zone area: pass.

### A.4 Z-frame, inner cap toward the burner

Frame 100 mm deep, inner cap 30 mm wide on a skin. Stand-off fixed by the scenario to the cap (2.4.3 step 3(i)).

| Surface | Category | Zone / condition |
| --- | --- | --- |
| Inner cap, web, skin beside the frame | K1 | By position |
| Web side and skin under the Z-return | K2 (2.4.3 step 5(d): b = 30 mm) | Zone of position |
| Skin at x = 2 s (100 mm behind the cap), outside the Z-return | K1 | At the limit of 2.4.4; inside the outermost contour: by position |
| Skin far side | K0 | As A.1: not impinged |

Hottest-zone area (projected): cap about 6 000 mm², skin the remainder of the Z1 area: pass. The skin, 200 mm from the cone exit, receives the main stagnation flow; the reference surface choice is agreed in the alignment meeting.

### A.5 L-clip smaller than Z1

2 mm clip, legs 50 mm × 40 mm, 40 mm wide, alone in its fixture. Reference surface per 2.4.3 step 3(iii).

| Surface (farthest corner at r ≈ 32 mm) | Category | Zone / condition |
| --- | --- | --- |
| Front face, edges, outer face of the 40 mm leg | K1 | Z1 (zone of position) |
| Back and inner faces | K2 (2.4.3 step 5(d): b = 40 mm, below 0.25 D1) | Z1 (zone of position) |

Hottest-zone area: projected area of the clip below 16 129 mm²: 2.4.3 step 11 case (i), recorded; alignment meeting (2.4.4). Part dimension below 0.25 D1 (50 mm): sensitivity S10. As installed, the attached structure inside the Z1 contour is included in the area check.

Variant: flat 2 mm clip 80 mm × 60 mm normal to the axis in Z1, alone in its fixture (b = 60 mm, 0.25 D1 ≤ b < D1): front face and edges K1, Z1; back face K3 (2.4.3 step 5(e)), 0.5 × VF_1 and 0.5 × HTC_1 (Z2 values): 58.2 kW/m² at 20 °C. Clip below 400 °C at the exposure time: S12 in the nominal case (2.4.4).

### A.6 Tube across the flame

Ø 25 mm tube crossing the axis at right angles; front at the reference surface. Reference surface per 2.4.3 step 3(iii).

| Portion | Category | Zone / condition |
| --- | --- | --- |
| \|y\| ≤ 100 mm | K1 for θ ≤ 100°; K2 for θ > 100° (2.4.3 step 5(d): b = 25 mm) | Z1, full circumference |
| 100 < \|y\| ≤ 200 mm | As above | Z2, full circumference |
| 200 < \|y\| ≤ 350 mm | As above | Z3, full circumference |
| Beyond 350 mm | — | Not impinged |

In this table y is the distance along the tube from the burner axis. Variant: Ø 60 mm duct (b = 60 mm): sector θ ≤ 100° K1; sector θ > 100° K3 (2.4.3 step 5(e)), in Z1 the Z2 values, 58.2 kW/m² at 20 °C. Hottest-zone area: projected area about 5 000 mm² (25 mm × 200 mm), below 16 129 mm²: 2.4.3 step 11 case (i), recorded; alignment meeting (2.4.4). Tube diameter below 0.25 D1: S10. A tube carrying fluid requires internal-side modelling (2.7.9).

### A.7 Firewall with bulkhead fitting

Flat firewall at the reference surface; hexagon 30 mm across flats protruding 30 mm toward the burner, on the axis.

| Surface | Category | Zone / condition |
| --- | --- | --- |
| Firewall flame side | K1 | By position |
| Hexagon (all faces) | K1 | Z1 |
| Firewall back face, nut and threads | K0 (2.4.3 step 5(a)) | Not impinged (gas-tight wall, edges outside Z3); conduction through the fitting |

Hexagon front face at x = 0.70 s: projection, recorded (2.4.4). Hottest-zone area 31 416 mm²: pass.

### A.8 Curved cowl, convex toward the burner

Radius of curvature 600 mm, apex on the axis at the reference surface.

| r | Fall-back from the reference plane | Normal tilt | Zone |
| --- | --- | --- | --- |
| 100 mm | 8 mm | 10° | Z1 |
| 200 mm | 34 mm | 19° | Z2 |
| 350 mm | 113 mm | 36° | Z3 |

Zones by projection. Convex face: K1 (θ ≤ 36°); back face: K0 (2.4.3 step 5(a)) where the cowl edges are outside the hottest-zone contour. The Z3 edge is at x = 2.13 s: projection, recorded (2.4.4, B1). Hottest-zone area: pass.

## Appendix B. Open points

### B.1 Extension to non-flat geometry

| ID | Open point | Evidence that would settle it |
| --- | --- | --- |
| B1 | Axial invariance of the hottest zone (projection independent of distance); grazing faces deeper than 2 s (2.4.4) | Plate tests at 0.5 s, 0.75 s, 1.5 s and 2 s; test E4 |
| B2 | Oblique impingement: peak location relative to the extruded hottest zone | Flat plate at 30°, 45°, 60° with a thermocouple grid |
| B3 | Small bodies and edges: heating rate versus Z1; rear faces of small bodies (K2); leading-edge and axial variation on grazing faces | Tubes Ø12, 25, 50 mm and strips 25, 50, 100 mm wide across the axis in Z1, front and rear thermocouples (test E1); a free plate edge on the axis; test E4 |
| B4 | Back-face rule for walls: categories K0 and K4, free edge or opening between the hottest-zone and outermost contours (2.4.3 step 5(a), 5(b)) | Plate with a free edge at each zone boundary, back-face thermocouples (test E3) |
| B5 | Cavities: rule 2.4.3 step 8 and embedded-loss assumption | Open U-channels, depth/width 0.5, 1, 2, with and without end closure; test E2 |
| B6 | Pocket faces under flanges: category K2, full zone flux (2.4.3 step 5(d)) | Stringer-side panel, flanges 20 mm and 60 mm, thermocouples on flange underside and shadowed skin (test E2) |
| B7 | Structure beyond the outermost zone on the buoyant side; radiation from impinged faces to non-impinged parts | Large plate or ceiling above a horizontal burner |
| B8 | Hottest-zone area criterion: origin of 5 in × 5 in, projected area in the calibration plane, and acceptability of the 50 % generic form | Standards [2], [4]; authority position |
| B9 | Acceptance status of each burner model and of the N-zone versions | Programme certification records |
| B10 | Source presentation [8] scenario 1 / scenario 2 classification versus the escalation levels of 2.4.5 | Alignment-meeting records on past programmes |
| B17 | Factor 0.5 and threshold 0.25 D1 of 2.4.3 step 5(e) | Test E1 |

Tests E1 to E4: existing burner, thin uncooled metallic specimens, thermocouples, inverse method. Criterion: identified flux at each thermocouple on a hidden face not above the flux of 2.4.3 step 5, from 20 °C to the steady temperature.

| Test | Specimen and instrumentation | Settles | Open points |
| --- | --- | --- | --- |
| E1 | Tubes Ø12, 25, 50 mm and strips 25, 50, 100 mm wide across the axis in Z1; thermocouples front and rear; heating rate and steady temperature | K2/K3 threshold, factor 0.5, T_ref ceiling (2.7.4), admissibility of a loss condition on leeward faces | B3, B17 |
| E2 | Stringer-side panel, flanges 20 mm and 60 mm; thermocouples on flange underside and shadowed skin | Pocket treatment (K2), S11 | B5, B6 |
| E3 | Plate with a free edge at r = 0.5, 1.0, 1.3 × D1/2; back-face thermocouples at 10, 50, 150 mm from the edge | Extent of K4; rule 5(a) for a free edge between the hottest-zone and outermost contours | B4, B12 |
| E4 | Plate edge-on to the flame, 100 mm deep; thermocouples at 10, 50, 90 mm from the leading edge | Grazing faces (K1), leading-edge excess, axial decay | B1, B3 |

### B.2 Owner actions

| ID | Open point | Action |
| --- | --- | --- |
| B11 | Continuous inclined reference surface: the inclination rows of 2.4.4 override the 0.5 s and 2 s rows | Confirm from the COMPUP geometry [12]: burner or spar inclined; extent of the spar on the near side |
| B12 | Basis of 2.4.3 step 5(a) for a free edge between the hottest-zone and outermost contours. The two-zone plates (254 mm × 254 mm) have edges at r = 127 mm to 180 mm, between the Z1 and Z2 contours. If the plates were tested with free edges and the inverse method used an ambient back face, rule 5(a) reproduces the identification for edges at r ≥ 127 mm | Confirm from [11]: free edges; back-face condition of the inverse method |
| B13 | Part VII: burner axis normal to the frame, lean direction, calibration attitude (1.5.2.1). Part III: cone orientation relative to the sidewall, measuring point of the 50 mm (2.3.3.1) | Confirm against [1] Appendix F Part VII Figures 1 and 2 and Part III Figure 1 |
| B14 | CS-Definitions wording of fireproof and fire resistant, and statement of the flame values (1.3.2) | Confirm against [6] |
| B15 | AC 20-135 burner list and AC 20-135A status ([4], 1.5.1.1); ISO 2685 values other than temperature and flux ([2], 1.5.1.1) | Confirm against [4] and [2] |
| B16 | Supply of T_allowable by stress before the sensitivities are scoped; value of the 100 °C margin threshold (2.8.4, 2.8.5) | Stress: T_allowable supply. 1ACST: threshold value |
| B18 | Burner gas velocity: not used by the method. The factor 0.5 of 2.4.3 step 5(e) is a judgement value based on rear-face convection of bluff bodies (B17) | Confirm that no gas velocity assumption is used in the method |
| B19 | ISO 2685 calibration heat flux on the water-cooled copper tube (1.5.1.1): circumferential average or local value; relation to the Z1 cold-wall flux and to the K2 rule on tube rear faces (A.6) | Confirm against [2] |

## Appendix C. Traceability to the source presentation

Items not stated in the source presentation [8] (ISO 2685 standard flame thermal model deck). Status: to be accepted.

| Section | Item |
| --- | --- |
| 1.1.2, 1.5.2, 1.5.3, 2.3.2, 2.3.3 | Extension of the method to Appendix F Part VII and Part III burners; burner data from CS-25 Appendix F |
| 1.1.4 | Exclusions |
| 1.1.5 | Conventions |
| 1.3.2 | Terms |
| 1.4 | Certification basis (CS-25 Amdt 27 text; fire threats) |
| 1.5 | Burner summary |
| 1.5.1.1 | AC 20-135 values; ISO 2685 acceptance criteria |
| 1.5.1.2 | Three-zone model used for all analyses (source presentation: recommended for characteristic length above 400 mm) |
| 2.1.2, 2.1.3 | Scenario content list; cases where the alignment meeting is mandatory |
| 2.1.4 | Mapping reduction check (20 °C) |
| 2.2.2, 2.2.4, 2.2.5 | Identification consequences; solver implementation; calibration check |
| 2.3.1.2 | Validity limits (stand-off, attitude) |
| 2.4, Appendix B | Extension to non-flat geometry: assessment of approaches, default procedure, triggers, escalation levels, open points (replaces the source-presentation scenario 1 / scenario 2 text, which is retained as candidate approaches in 2.4.2) |
| 2.4.3, 2.8.4 | Face categories K0 to K4 (2.4.3 step 5); factor 0.5 on VF_i and HTC_i of sheltered faces (K3); sensitivity S12 |
| 2.5.1, 2.5.3, 2.5.4 | Toolset table; cut boundary criteria; initial and boundary conditions |
| 2.6.1, 2.6.2, 2.6.3 | Operating phases per burner; second ToO case; AMC 25.1193(e) post-onset conditions |
| 2.7 | Points of attention except the composite limitation of 2.7.6 |
| 2.8 | Validity table entries, limitations, uncertainty sources, sensitivity set, margins, out-of-range route |
| 2.9 | Gradient check timing and exemption; shell thickness limits; time integration; mass smearing; contacts and enclosures; verification checks |
| 2.9.5 | Lower-bound emissivity on back faces of impinged parts |
| 2.10.1 | Test/prediction comparison |
| Appendix A | Projection examples |

## Appendix D. Change record

Section and figure numbers in each row refer to the issue concerned.

| Issue | Changes |
| --- | --- |
| Draft A (2026-11-20) | First issue, ISO 2685 burner; replaces the zone projection procedure [9] (2026-10-31): face classes A–I of [9] replaced; specimen emissivity rule replaced by ε_wall = 1; horizontal axis covered; guidance of [9] on composite outgassing removed; zone radii 100 / 200 / 350 mm |
| Draft B (2026-11-20) | Extended to Appendix F Part VII and Part III burners with a common model form; certification basis added; burner data grouped in section 7; non-flat geometry rewritten (projection with generic back-face and cavity rules, triggers, escalation levels, open points); hidden-face cases F1–F3 of Draft A replaced by 8.3 step 6; burner summary table (section 7); back-face rule aligned with the identification boundary conditions; one condition per shell face; hottest-zone area basis; AMC 25.1193(e) post-onset conditions corrected |
| Draft C (2026-11-21) | Terms added (3.2); status of section 8 rules (1.5, 8.1); 8.3 steps 3 to 6, 8, 10 and 11 revised (rule for faces behind a wall, opening threshold 1 %, reference surface and reference plane, cavity limits, positions, projected hottest-zone area); 8.4 triggers in x; 8.5 level 2 bounding case with T_ref + δT; calibration check at two wall temperatures (6.5, 13.7); lower-bound back-face emissivity (13.5); S1 withdrawn, S2 at the upper tolerances of flux and temperature, S3, S4, S6, S7 and S10 defined with magnitudes, S11 limited at T_ref (12.4); margin definition and decision table (12.5); Part VII attitude and calibration rig, Part III geometry, CS-Definitions and AC 20-135 items flagged to be confirmed; CS-25 paraphrases completed; references [8], [9] added; burner summary of section 7 without subsection number; Figures 1, 4, 6, 7 updated; owner actions B11 to B16 |
| Draft D (2026-11-21) | 8.3 steps 4 to 8 replaced by face categories K0 to K4 applied in order (not impinged, behind a wall, visible, wrapped, sheltered); hidden face, shadowing part, b and θ defined; wall defined by D1 (3.2); sheltered faces (K3, 0.25 D1 ≤ b < D1, open wake) take 0.5 × VF_i and 0.5 × HTC_i of the zone of position, not below ZN (6.4); free edge between the hottest-zone and outermost contours under 5(a), recorded; known simplifications of 8.3 revised; 6.3 item 1, 8.2 face-class row, 14.2, 14.4 aligned; 8.4 rows for K3 faces below 400 °C and grazing faces deeper than 2 s; S12 added (12.4, 12.5); categories per surface and K3 variants in Appendix A, zones unchanged; B1, B3 to B6, B12 revised, B17 to B19 and tests E1 to E4 added (Appendix B); Figure 6 panel (b) label |
| Draft E (2026-11-23) | Restructured in two chapters: context and certification basis (chapter 1); simulation method (chapter 2). No technical change. |
